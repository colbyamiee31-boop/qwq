"""Execute archived experiment definitions with only path and API compatibility adaptation."""
from pathlib import Path
import sys,json,hashlib,importlib.util,subprocess,time,contextlib,ast,difflib,shutil,csv,os
import numpy as np,pandas as pd,casadi as ca
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent.parent
V12=ROOT/'v12/VALIDATION1_2_GREENLIGHT_FLOWMAP';V13=ROOT/'v13/VALIDATION1_3_CONE_LIFT_AUDIT'
lane=sys.argv[1];assert lane in ('archive_definition','frozen_source')
stage=ROOT/'runs'/lane;stage.mkdir(parents=True,exist_ok=True)
for n in ['v12','logs','adapted_scripts','snapshots']: (stage/n).mkdir(exist_ok=True)
assert sys.version_info[:3]==(3,11,16) and np.__version__=='1.26.4' and ca.__version__=='3.8.1'
from gl_gym.configs import default_params as pm
from gl_gym.environments import utils as em
from gl_gym.models.GreenLight import utils as mm
from gl_gym.models.GreenLight import ode as om
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
if lane=='archive_definition':
 rc=V12/'runtime_reconstruction'
 pm.init_default_params=load('rec_params',rc/'default_params.py').init_default_params
 em.init_state=load('rec_init',rc/'utils.py').init_state
 sys.modules['gl_gym.models.GreenLight.aux_states']=load('rec_aux',rc/'aux_states.py')
 om.ODE=load('rec_ode',rc/'ode.py').ODE
else:
 native_params=pm.init_default_params
 pm.init_default_params=lambda nparams=208:native_params(nparams)
calls=[]
def define_model(nx,nu,nd,n_params,dt,abstol=1e-4,reltol=1e-4,max_num_steps=70000):
 # Frozen native integrator definition; keyword extension ONLY exposes archived tight settings.
 x=ca.SX.sym('x',nx);u=ca.SX.sym('u',nu);d=ca.SX.sym('d',nd);p=ca.SX.sym('p',n_params)
 opts={'abstol':abstol,'reltol':reltol,'max_num_steps':max_num_steps}
 calls.append({'stage':current_name,'dt':dt,**opts})
 return ca.integrator('F','cvodes',{'x':x,'u':u,'p':ca.vertcat(d,p),'ode':om.ODE(x,u,d,p)},0.,dt,opts)
mm.define_model=define_model
inputs=ROOT/'inputs';inputs.mkdir(exist_ok=True)
hist=Path(os.environ.get('V14_HISTORICAL_DIR',str(WORK/'work/historical/EXP1_2_historical')))
# Archive contains headline reference columns; use those exact values, not regenerated estimates.
headline=pd.read_csv(V12/'V1_2_FROZEN_HEADLINE_REGRESSION.csv')
stored=pd.DataFrame({'baseline_air_temperature_c':headline.stored_base_T,'delta_T_high_minus_low_c':headline.stored_delta_T,'delta_VP_high_minus_low_pa':headline.stored_delta_vp,'baseline_air_co2_ppm':headline.stored_base_co2})
stored.to_csv(inputs/'EXP1_2_LOCAL_MATCHED_STATE_PROBES.csv',index=False)
jobs=['regression.py','validation12_default.py','validation12_path.py','validation12_tight.py','validation12_refine900.py','validation12_slice_tight.py','validation12_examples.py','run_validation13.py']
timings=[];adaptations=[]
for name in jobs:
 current_name=name
 src=V13/name if name=='run_validation13.py' else V12/'runtime_reconstruction'/name
 raw=src.read_text(encoding='utf8');s=raw
 mapping={
 '/mnt/data/validation1_work/matched/EXP0_5_BENCHMARK_FORCING.csv':(hist/'physbench/exp0_5/benchmark_forcing.csv').as_posix(),
 '/mnt/data/validation1_work/matched/EXP0_5_MATCHED_INITIAL_STATE.json':(hist/'physbench/exp0_5/matched_initial_state.json').as_posix(),
 '/mnt/data/validation1_work/exp12/EXP1_2_LOCAL_MATCHED_STATE_PROBES.csv':(inputs/'EXP1_2_LOCAL_MATCHED_STATE_PROBES.csv').as_posix(),
 '/mnt/data/VALIDATION1_2_GREENLIGHT_FLOWMAP':V12.as_posix(),
 '/mnt/data/VALIDATION1_3_CONE_LIFT_AUDIT_2026-10-02.zip':(stage/'v13_original_runner_outputs.zip').as_posix(),
 '/mnt/data/VALIDATION1_3_CONE_LIFT_AUDIT':(stage/'v13').as_posix(),
 '/mnt/data/run_validation13.py':(stage/'adapted_scripts/run_validation13.py').as_posix(),
 '/mnt/data/gl_rebuild':(stage/'v12').as_posix()}
 # Prespecified persistent candidates are frozen from the original path CSV, not re-selected.
 if name=='validation12_tight.py':
  mapping={'/mnt/data/gl_rebuild/V1_2_PATHWISE_60S_AUDIT.csv':(V12/'V1_2_PATHWISE_60S_AUDIT.csv').as_posix(),**mapping}
 for a,b in mapping.items():s=s.replace(a,b)
 if name=='run_validation13.py':
  # Refuse overwrite: every lane writes to a new task-owned path. No recursive deletion.
  assert not (stage/'v13').exists(),'V13 output already exists; do not overwrite'
  s=s.replace('if OUT.exists(): shutil.rmtree(OUT)',"assert not OUT.exists(), 'Output must be new'")
  s=s.replace('if zip_path.exists(): zip_path.unlink()',"assert not zip_path.exists(), 'ZIP must be new'")
 adapted=stage/'adapted_scripts'/name;adapted.write_text(s,encoding='utf8')
 (stage/'adapted_scripts'/(name+'.diff')).write_text(''.join(difflib.unified_diff(raw.splitlines(True),s.splitlines(True),fromfile='original/'+name,tofile='adapted/'+name)),encoding='utf8')
 adaptations.append({'script':name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'adapted_sha256':hashlib.sha256(adapted.read_bytes()).hexdigest(),'changes':'absolute paths only; V13 destructive overwrite becomes assertion; tight uses original candidate CSV'})
 print('START',lane,name,flush=True);t=time.time()
 with (stage/'logs'/(name+'.log')).open('w',encoding='utf8') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
  ns={'__name__':'__main__','__file__':str(adapted)}
  exec(compile(s,str(adapted),'exec'),ns)
 elapsed=time.time()-t
 # Export already-computed arrays for audit; no numerical computation altered.
 arrays={k:ns[k] for k in ['X','D','LO','HI','lowT','highT','Jall','flow','fhigh','base','p'] if k in ns}
 if arrays:np.savez_compressed(stage/'snapshots'/(name+'.npz'),**arrays)
 timings.append({'stage':name,'seconds':elapsed,'status':'completed'})
 (stage/'timings.json').write_text(json.dumps(timings,indent=2))
 (stage/'integrator_calls.json').write_text(json.dumps(calls,indent=2))
 (stage/'adaptations.json').write_text(json.dumps(adaptations,indent=2))
 print('DONE',lane,name,round(elapsed,3),flush=True)
print('ALL_COMPLETED',lane,flush=True)
