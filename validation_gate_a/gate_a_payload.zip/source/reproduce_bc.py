"""Portable entry: rerun archived definitions in a NEW directory; no Linux exact-runtime claim."""
from pathlib import Path
import argparse,json,subprocess,sys,os,zipfile,hashlib,importlib.metadata as md
p=argparse.ArgumentParser();p.add_argument('--work-dir',required=True);p.add_argument('--lane',choices=['archive_definition','frozen_source','both'],default='both');a=p.parse_args()
bundle=Path(__file__).resolve().parents[1];dest=Path(a.work_dir).resolve()
if dest.exists() and any(dest.iterdir()):raise SystemExit('Use a new empty work directory; existing evidence will not be overwritten')
assert sys.version_info[:3]==(3,11,16),sys.version
for name,want in [('numpy','1.26.4'),('casadi','3.8.1'),('gl-gym','0.3.2')]:assert md.version(name)==want,(name,md.version(name))
import gl_gym
installed=Path(gl_gym.__file__).parent
with zipfile.ZipFile(bundle/'source/GreenLight-Gym2_2d3febb1.zip') as z:
 for name in ['configs/default_params.py','environments/utils.py','models/GreenLight/ode.py','models/GreenLight/aux_states.py','models/GreenLight/utils.py']:
  assert z.read('gl_gym/'+name).replace(b'\r\n',b'\n')==(installed/name).read_bytes().replace(b'\r\n',b'\n'),('frozen source mismatch',name)
dest.mkdir(parents=True,exist_ok=True)
for archive,sub in [('VALIDATION1_2_GREENLIGHT_FLOWMAP_COUNTEREXAMPLES_2026-10-01.zip','v12'),('VALIDATION1_3_CONE_LIFT_AUDIT_2026-10-02.zip','v13'),('EXP1_2_historical.zip','historical')]:
 with zipfile.ZipFile(bundle/'originals'/archive) as z:
  assert z.testzip() is None
  for name in z.namelist():assert (dest/sub/name).resolve().is_relative_to((dest/sub).resolve())
  z.extractall(dest/sub)
script=dest/'run_definition.py';script.write_bytes((bundle/'source/run_definition.py').read_bytes())
env=os.environ.copy();env['V14_HISTORICAL_DIR']=str(dest/'historical')
lanes=['archive_definition','frozen_source'] if a.lane=='both' else [a.lane]
for lane in lanes:
 with (dest/(lane+'_runtime.log')).open('w',encoding='utf8') as f:
  subprocess.run([sys.executable,'-u','-X','utf8',str(script),lane],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
print(json.dumps({'completed':lanes,'work_dir':str(dest),'scope':'Definition-preserving B/C only; postprocessing/comparison tables are separate from raw runner output','exact_frozen_runtime':False,'Gate_A':'OPEN'},indent=2))
